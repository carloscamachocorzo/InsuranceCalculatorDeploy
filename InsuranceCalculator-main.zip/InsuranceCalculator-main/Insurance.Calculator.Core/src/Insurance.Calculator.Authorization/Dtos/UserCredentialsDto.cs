﻿namespace Insurance.Calculator.Authorization.Dtos
{
    public class UserCredentialsDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}

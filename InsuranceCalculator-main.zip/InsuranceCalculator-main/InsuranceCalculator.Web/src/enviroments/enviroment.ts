export const environment = {
  production: true,
  backend: 'http://localhost:52596/api'
};
